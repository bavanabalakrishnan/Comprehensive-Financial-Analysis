"""
BITCOIN vs STOCK - COMPREHENSIVE FINANCIAL ANALYSIS
Covers: Preprocessing, Returns, Risk, Correlation,
        Anomaly Detection, ARMA, Regression, Insights

DATASETS REQUIRED (download from Kaggle and place in same folder):
  1. Bitcoin : https://www.kaggle.com/datasets/priyamchoksi/bitcoin-historical-prices-and-activity-2010-2024
     Expected file: btc_price.csv  (or rename your downloaded file)
  2. Stock   : https://www.kaggle.com/datasets/anitarostami/historical-stock-price-dataset
     Expected file: stock_price.csv (or rename your downloaded file)

HOW TO RUN:
  pip install pandas numpy matplotlib seaborn scipy statsmodels scikit-learn
  python financial_analysis_project.py
"""

# ------------------------------------------------------------------
# IMPORTS
# ------------------------------------------------------------------
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns
from scipy import stats
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings("ignore")

# ------------------------------------------------------------------
# GLOBAL STYLE
# ------------------------------------------------------------------
plt.rcParams.update({
    "figure.facecolor": "#0d1117",
    "axes.facecolor":   "#161b22",
    "axes.edgecolor":   "#30363d",
    "axes.labelcolor":  "#e6edf3",
    "xtick.color":      "#8b949e",
    "ytick.color":      "#8b949e",
    "text.color":       "#e6edf3",
    "grid.color":       "#21262d",
    "grid.linestyle":   "--",
    "grid.alpha":       0.5,
    "lines.linewidth":  1.5,
    "font.family":      "monospace",
})

BTC_COLOR   = "#f7931a"
STOCK_COLOR = "#58a6ff"
DANGER      = "#ff6b6b"
SUCCESS     = "#3fb950"

SECTION_BAR = "=" * 70


def section(title: str):
    print(f"\n{SECTION_BAR}")
    print(f"  {title}")
    print(SECTION_BAR)


def save_fig(name: str):
    plt.tight_layout()
    plt.savefig(f"{name}.png", dpi=150, bbox_inches="tight",
                facecolor="#0d1117")
    print(f"  Saved: {name}.png")
    plt.close()


# ==================================================================
# STEP 1 - DATA COLLECTION
# ==================================================================
section("STEP 1 - DATA COLLECTION")

BTC_FILE   = "btc_price.csv"
STOCK_FILE = "stock_price.csv"


def load_or_generate_btc():
    try:
        df = pd.read_csv(BTC_FILE)
        print(f"  Bitcoin data loaded: {df.shape}")
        return df
    except FileNotFoundError:
        print("  btc_price.csv not found - generating synthetic BTC data for demo")
        np.random.seed(42)
        dates = pd.date_range("2015-01-01", "2024-12-31", freq="D")
        n = len(dates)
        drift = 0.0008
        vol   = 0.03
        log_ret = np.random.normal(drift, vol, n)
        price = 300 * np.exp(np.cumsum(log_ret))
        volume = np.random.randint(5_000_000, 50_000_000, n)
        high = price * (1 + np.abs(np.random.normal(0, 0.015, n)))
        low  = price * (1 - np.abs(np.random.normal(0, 0.015, n)))
        df = pd.DataFrame({
            "Date": dates, "Open": price * np.random.uniform(0.98, 1.02, n),
            "High": high, "Low": low, "Close": price, "Volume": volume
        })
        df.to_csv(BTC_FILE, index=False)
        return df


def load_or_generate_stock():
    try:
        df = pd.read_csv(STOCK_FILE)
        print(f"  Stock data loaded: {df.shape}")
        return df
    except FileNotFoundError:
        print("  stock_price.csv not found - generating synthetic stock data for demo")
        np.random.seed(99)
        dates = pd.date_range("2015-01-01", "2024-12-31", freq="B")
        n = len(dates)
        drift = 0.0003
        vol   = 0.012
        log_ret = np.random.normal(drift, vol, n)
        price = 50 * np.exp(np.cumsum(log_ret))
        volume = np.random.randint(1_000_000, 10_000_000, n)
        df = pd.DataFrame({
            "Date": dates, "Open": price * np.random.uniform(0.99, 1.01, n),
            "High": price * (1 + np.abs(np.random.normal(0, 0.008, n))),
            "Low":  price * (1 - np.abs(np.random.normal(0, 0.008, n))),
            "Close": price, "Volume": volume
        })
        df.to_csv(STOCK_FILE, index=False)
        return df


btc_raw   = load_or_generate_btc()
stock_raw = load_or_generate_stock()


# ==================================================================
# STEP 2 - DATA PREPROCESSING
# ==================================================================
section("STEP 2 - DATA PREPROCESSING (DATA WRANGLING)")


def preprocess(df: pd.DataFrame, label: str) -> pd.DataFrame:
    df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]
    print(f"\n  [{label}] Cleaned columns: {list(df.columns)}")

    date_col = next((c for c in df.columns if "date" in c or "time" in c), None)
    if date_col is None:
        raise ValueError(f"No date column found in {label}")
    df.rename(columns={date_col: "date"}, inplace=True)

    df["date"] = pd.to_datetime(df["date"], infer_datetime_format=True,
                                errors="coerce")
    df.dropna(subset=["date"], inplace=True)

    needed = ["open", "high", "low", "close", "volume"]
    col_map = {}
    for need in needed:
        match = next((c for c in df.columns if need in c), None)
        if match:
            col_map[match] = need
    df.rename(columns=col_map, inplace=True)
    keep = ["date"] + [c for c in needed if c in df.columns]
    df = df[keep].copy()

    before = len(df)
    df.dropna(subset=["close"], inplace=True)
    df[needed[:-1]] = df[needed[:-1]].fillna(method="ffill")
    df["volume"] = df["volume"].fillna(0)
    after = len(df)
    print(f"  [{label}] Rows before/after NaN drop: {before} to {after}")

    df.sort_values("date", inplace=True)
    df.reset_index(drop=True, inplace=True)

    print(f"  [{label}] Date range: {df['date'].min().date()} to "
          f"{df['date'].max().date()}")
    return df


btc   = preprocess(btc_raw.copy(),   "BTC")
stock = preprocess(stock_raw.copy(), "STOCK")

common_start = max(btc["date"].min(), stock["date"].min())
common_end   = min(btc["date"].max(), stock["date"].max())
btc   = btc[(btc["date"] >= common_start) & (btc["date"] <= common_end)].copy()
stock = stock[(stock["date"] >= common_start) & (stock["date"] <= common_end)].copy()
print(f"\n  Aligned date range: {common_start.date()} to {common_end.date()}")
print(f"  BTC rows: {len(btc)} | Stock rows: {len(stock)}")


# ==================================================================
# STEP 3 - RETURN ANALYSIS
# ==================================================================
section("STEP 3 - RETURN ANALYSIS")

btc["daily_return"]   = btc["close"].pct_change()
stock["daily_return"] = stock["close"].pct_change()

btc["cum_return"]   = (1 + btc["daily_return"]).cumprod() - 1
stock["cum_return"] = (1 + stock["daily_return"]).cumprod() - 1

print(f"  BTC   total return : {btc['cum_return'].iloc[-1]*100:.1f}%")
print(f"  Stock total return : {stock['cum_return'].iloc[-1]*100:.1f}%")
print(f"  BTC   avg daily    : {btc['daily_return'].mean()*100:.3f}%")
print(f"  Stock avg daily    : {stock['daily_return'].mean()*100:.3f}%")

fig, axes = plt.subplots(2, 1, figsize=(14, 8))
fig.suptitle("RETURN ANALYSIS", fontsize=14, fontweight="bold", color="#e6edf3")

ax1 = axes[0]
ax1.plot(btc["date"],   btc["daily_return"]*100,   color=BTC_COLOR,
         alpha=0.7, label="BTC Daily Return")
ax1.plot(stock["date"], stock["daily_return"]*100, color=STOCK_COLOR,
         alpha=0.7, label="Stock Daily Return")
ax1.axhline(0, color="#8b949e", linewidth=0.8)
ax1.set_ylabel("Daily Return (%)")
ax1.set_title("Daily Returns", fontsize=11)
ax1.legend()
ax1.grid(True)

ax2 = axes[1]
ax2.plot(btc["date"],   btc["cum_return"]*100,   color=BTC_COLOR,   label="BTC Cumulative")
ax2.plot(stock["date"], stock["cum_return"]*100, color=STOCK_COLOR, label="Stock Cumulative")
ax2.set_ylabel("Cumulative Return (%)")
ax2.set_title("Cumulative Returns Over Time", fontsize=11)
ax2.legend()
ax2.grid(True)
save_fig("03_return_analysis")


# ==================================================================
# STEP 4 - RISK ANALYSIS
# ==================================================================
section("STEP 4 - RISK ANALYSIS")

WINDOW = 30

btc["volatility"]   = btc["daily_return"].rolling(WINDOW).std() * np.sqrt(252)
stock["volatility"] = stock["daily_return"].rolling(WINDOW).std() * np.sqrt(252)

RISK_FREE = 0.0
btc_sharpe   = ((btc["daily_return"].mean() - RISK_FREE/252) /
                btc["daily_return"].std()) * np.sqrt(252)
stock_sharpe = ((stock["daily_return"].mean() - RISK_FREE/252) /
                stock["daily_return"].std()) * np.sqrt(252)

print(f"  BTC   annualised volatility : "
      f"{btc['volatility'].mean()*100:.1f}%")
print(f"  Stock annualised volatility : "
      f"{stock['volatility'].mean()*100:.1f}%")
print(f"  BTC   Sharpe Ratio          : {btc_sharpe:.3f}")
print(f"  Stock Sharpe Ratio          : {stock_sharpe:.3f}")

fig, axes = plt.subplots(2, 1, figsize=(14, 8))
fig.suptitle("RISK ANALYSIS", fontsize=14, fontweight="bold", color="#e6edf3")

axes[0].plot(btc["date"],   btc["volatility"]*100,   color=BTC_COLOR,   label="BTC Volatility")
axes[0].plot(stock["date"], stock["volatility"]*100, color=STOCK_COLOR, label="Stock Volatility")
axes[0].set_ylabel(f"Rolling {WINDOW}d Volatility (Ann. %)")
axes[0].set_title("Rolling Volatility (Annualised)", fontsize=11)
axes[0].legend(); axes[0].grid(True)

ax_sharpe = axes[1]
bars = ax_sharpe.bar(["BTC", "Stock"], [btc_sharpe, stock_sharpe],
                     color=[BTC_COLOR, STOCK_COLOR], width=0.4)
ax_sharpe.axhline(0, color="#8b949e", linewidth=0.8)
for bar, val in zip(bars, [btc_sharpe, stock_sharpe]):
    ax_sharpe.text(bar.get_x() + bar.get_width()/2,
                   val + 0.02 if val >= 0 else val - 0.08,
                   f"{val:.3f}", ha="center", va="bottom",
                   color="#e6edf3", fontweight="bold")
ax_sharpe.set_ylabel("Sharpe Ratio (annualised)")
ax_sharpe.set_title("Risk-Adjusted Return: Sharpe Ratio", fontsize=11)
ax_sharpe.grid(True, axis="y")
save_fig("04_risk_analysis")


# ==================================================================
# STEP 5 - MULTI-ASSET COMPARISON
# ==================================================================
section("STEP 5 - MULTI-ASSET COMPARISON")

fig, axes = plt.subplots(1, 3, figsize=(18, 6))
fig.suptitle("MULTI-ASSET COMPARISON: Bitcoin vs Stock",
             fontsize=14, fontweight="bold", color="#e6edf3")

axes[0].plot(btc["date"],   btc["close"] / btc["close"].iloc[0] * 100,
             color=BTC_COLOR,   label="BTC")
axes[0].plot(stock["date"], stock["close"] / stock["close"].iloc[0] * 100,
             color=STOCK_COLOR, label="Stock")
axes[0].set_title("Normalised Price (Base=100)")
axes[0].set_ylabel("Index"); axes[0].legend(); axes[0].grid(True)

axes[1].hist(btc["daily_return"].dropna() * 100,   bins=80,
             color=BTC_COLOR,   alpha=0.6, label="BTC", density=True)
axes[1].hist(stock["daily_return"].dropna() * 100, bins=80,
             color=STOCK_COLOR, alpha=0.6, label="Stock", density=True)
axes[1].set_title("Daily Return Distribution")
axes[1].set_xlabel("Daily Return (%)"); axes[1].legend(); axes[1].grid(True)

axes[2].scatter(btc["volatility"].dropna() * 100,
                btc["daily_return"].rolling(30).mean().dropna() * 100,
                color=BTC_COLOR,   alpha=0.15, s=8, label="BTC")
axes[2].scatter(stock["volatility"].dropna() * 100,
                stock["daily_return"].rolling(30).mean().dropna() * 100,
                color=STOCK_COLOR, alpha=0.15, s=8, label="Stock")
axes[2].set_xlabel("30d Volatility (%)"); axes[2].set_ylabel("30d Avg Return (%)")
axes[2].set_title("Risk vs Return Cloud"); axes[2].legend(); axes[2].grid(True)
save_fig("05_multi_asset_comparison")


# ==================================================================
# STEP 6 - CORRELATION ANALYSIS
# ==================================================================
section("STEP 6 - CORRELATION ANALYSIS")

merged = pd.merge(
    btc[["date", "close", "daily_return"]].rename(
        columns={"close": "btc_close", "daily_return": "btc_ret"}),
    stock[["date", "close", "daily_return"]].rename(
        columns={"close": "stk_close", "daily_return": "stk_ret"}),
    on="date", how="inner"
).dropna()

price_corr  = merged["btc_close"].corr(merged["stk_close"])
return_corr = merged["btc_ret"].corr(merged["stk_ret"])
print(f"  Price  correlation  : {price_corr:.4f}")
print(f"  Return correlation  : {return_corr:.4f}")

merged["rolling_corr"] = (
    merged["btc_ret"].rolling(60)
    .corr(merged["stk_ret"])
)

fig, axes = plt.subplots(1, 2, figsize=(16, 6))
fig.suptitle("CORRELATION ANALYSIS", fontsize=14, fontweight="bold",
             color="#e6edf3")

axes[0].scatter(merged["btc_ret"]*100, merged["stk_ret"]*100,
                alpha=0.15, s=6, color="#a371f7")
m, b = np.polyfit(merged["btc_ret"], merged["stk_ret"], 1)
xline = np.linspace(merged["btc_ret"].min(), merged["btc_ret"].max(), 200)
axes[0].plot(xline*100, (m*xline+b)*100, color=DANGER, linewidth=1.5,
             label=f"r = {return_corr:.3f}")
axes[0].set_xlabel("BTC Daily Return (%)")
axes[0].set_ylabel("Stock Daily Return (%)")
axes[0].set_title(f"Return Scatter  |  Pearson r = {return_corr:.3f}")
axes[0].legend(); axes[0].grid(True)

axes[1].plot(merged["date"], merged["rolling_corr"],
             color="#a371f7", linewidth=1)
axes[1].axhline(0, color="#8b949e", linewidth=0.8, linestyle="--")
axes[1].fill_between(merged["date"], merged["rolling_corr"], 0,
                     where=merged["rolling_corr"] > 0,
                     alpha=0.2, color=SUCCESS)
axes[1].fill_between(merged["date"], merged["rolling_corr"], 0,
                     where=merged["rolling_corr"] < 0,
                     alpha=0.2, color=DANGER)
axes[1].set_ylabel("Rolling 60d Correlation")
axes[1].set_title("Rolling Correlation of Daily Returns (60d window)")
axes[1].grid(True)
save_fig("06_correlation_analysis")


# ==================================================================
# STEP 7 - ANOMALY DETECTION
# ==================================================================
section("STEP 7 - ANOMALY DETECTION")

ZSCORE_THRESHOLD = 3.0


def detect_anomalies(df: pd.DataFrame, label: str) -> pd.DataFrame:
    df = df.copy()
    df["z_score"] = stats.zscore(df["daily_return"].fillna(0))
    df["anomaly"] = df["z_score"].abs() > ZSCORE_THRESHOLD
    n = df["anomaly"].sum()
    print(f"  [{label}] Anomalies detected (|Z| > {ZSCORE_THRESHOLD}): {n} days")
    return df


btc   = detect_anomalies(btc,   "BTC")
stock = detect_anomalies(stock, "STOCK")

fig, axes = plt.subplots(2, 1, figsize=(16, 10))
fig.suptitle("ANOMALY DETECTION  (Z-Score Threshold = +/-3)",
             fontsize=14, fontweight="bold", color="#e6edf3")

for ax, df, color, label in [
    (axes[0], btc,   BTC_COLOR,   "Bitcoin"),
    (axes[1], stock, STOCK_COLOR, "Stock"),
]:
    ax.plot(df["date"], df["close"], color=color, linewidth=1, label=label)
    anomalies = df[df["anomaly"]]
    ax.scatter(anomalies["date"], anomalies["close"],
               color=DANGER, s=40, zorder=5, label="Anomaly")
    ax.set_ylabel("Close Price"); ax.legend(); ax.grid(True)
    ax.set_title(f"{label} - Price with Anomalies Highlighted")

save_fig("07_anomaly_detection")


# ==================================================================
# STEP 8 - TIME SERIES MODELING (ARIMA)
# ==================================================================
section("STEP 8 - TIME SERIES MODELING (ARIMA)")

ARIMA_N = 500
TEST_N  = 60

btc_ts  = btc["daily_return"].dropna().iloc[-ARIMA_N:].reset_index(drop=True)
train   = btc_ts.iloc[:-TEST_N]
test    = btc_ts.iloc[-TEST_N:]

print("  Fitting ARIMA(2,0,2) on BTC daily returns ...")
model   = ARIMA(train, order=(2, 0, 2))
result  = model.fit()
print(result.summary().tables[0])

forecast = result.forecast(steps=TEST_N)

fig, axes = plt.subplots(1, 2, figsize=(18, 6))
fig.suptitle("TIME SERIES MODELING - ARIMA(2,0,2) on BTC Daily Returns",
             fontsize=14, fontweight="bold", color="#e6edf3")

idx_test = range(len(train), len(train) + TEST_N)
axes[0].plot(range(len(btc_ts)), btc_ts * 100,
             color=BTC_COLOR, alpha=0.6, label="Actual", linewidth=1)
axes[0].plot(idx_test, forecast.values * 100,
             color=DANGER, linewidth=2, label="Forecast")
axes[0].axvline(len(train), color="#8b949e", linestyle="--", linewidth=1,
                label="Train | Test split")
axes[0].set_xlabel("Time step")
axes[0].set_ylabel("Daily Return (%)")
axes[0].set_title("Actual vs ARIMA Forecast")
axes[0].legend(); axes[0].grid(True)

residuals = result.resid
axes[1].plot(residuals * 100, color="#a371f7", linewidth=0.8, alpha=0.8)
axes[1].axhline(0, color="#8b949e", linewidth=0.8, linestyle="--")
axes[1].set_title("ARIMA Residuals")
axes[1].set_ylabel("Residual (%)"); axes[1].grid(True)
save_fig("08_arima_model")

fig2, ax2 = plt.subplots(1, 2, figsize=(14, 5))
fig2.suptitle("ACF & PACF of BTC Daily Returns", fontsize=13,
              fontweight="bold", color="#e6edf3")
plot_acf( btc_ts, ax=ax2[0], lags=40, color=BTC_COLOR, alpha=0.05)
plot_pacf(btc_ts, ax=ax2[1], lags=40, color=BTC_COLOR, alpha=0.05)
ax2[0].set_title("Autocorrelation Function (ACF)")
ax2[1].set_title("Partial Autocorrelation (PACF)")
save_fig("08b_acf_pacf")


# ==================================================================
# STEP 9 - REGRESSION MODEL
# ==================================================================
section("STEP 9 - REGRESSION MODEL (Predict Close Price)")


def run_regression(df: pd.DataFrame, label: str):
    df = df.dropna(subset=["open","high","low","volume","close"]).copy()
    features = ["open", "high", "low", "volume"]
    X = df[features].values
    y = df["close"].values

    split = int(len(df) * 0.8)
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s  = scaler.transform(X_test)

    reg = LinearRegression()
    reg.fit(X_train_s, y_train)
    y_pred = reg.predict(X_test_s)

    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2   = r2_score(y_test, y_pred)

    print(f"  [{label}] R2: {r2:.4f} | RMSE: {rmse:.4f}")
    print(f"  [{label}] Coefficients:")
    for f, c in zip(features, reg.coef_):
        print(f"       {f:10s}: {c:+.4f}")

    return y_test, y_pred, r2, rmse, df.index[split:]


btc_yt,   btc_yp,   btc_r2,   btc_rmse,   btc_idx   = run_regression(btc,   "BTC")
stock_yt, stock_yp, stock_r2, stock_rmse, stock_idx = run_regression(stock, "STOCK")

fig, axes = plt.subplots(1, 2, figsize=(18, 6))
fig.suptitle("REGRESSION MODEL - Predicted vs Actual Close Price",
             fontsize=14, fontweight="bold", color="#e6edf3")

for ax, yt, yp, r2, rmse, label, color in [
    (axes[0], btc_yt,   btc_yp,   btc_r2,   btc_rmse,   "BTC",   BTC_COLOR),
    (axes[1], stock_yt, stock_yp, stock_r2, stock_rmse, "Stock", STOCK_COLOR),
]:
    ax.plot(yt,     color=color,  alpha=0.7,  linewidth=1,   label="Actual")
    ax.plot(yp,     color=DANGER, linewidth=1.2, linestyle="--", label="Predicted")
    ax.set_title(f"{label}  |  R2 = {r2:.4f}  RMSE = {rmse:.2f}")
    ax.set_xlabel("Test Sample Index"); ax.set_ylabel("Close Price")
    ax.legend(); ax.grid(True)
save_fig("09_regression_model")


# ==================================================================
# STEP 10 - FEATURE ANALYSIS
# ==================================================================
section("STEP 10 - FEATURE ANALYSIS (Correlation Matrix)")

fig, axes = plt.subplots(1, 2, figsize=(16, 7))
fig.suptitle("FEATURE CORRELATION MATRIX", fontsize=14,
             fontweight="bold", color="#e6edf3")

for ax, df, label in [(axes[0], btc, "BTC"), (axes[1], stock, "Stock")]:
    cols = [c for c in ["open","high","low","close","volume","daily_return",
                         "volatility","z_score"] if c in df.columns]
    corr_mat = df[cols].corr()

    mask = np.triu(np.ones_like(corr_mat, dtype=bool))
    cmap = sns.diverging_palette(240, 10, as_cmap=True)
    sns.heatmap(corr_mat, ax=ax, mask=mask, cmap=cmap,
                annot=True, fmt=".2f", annot_kws={"size": 8},
                linewidths=0.5, linecolor="#0d1117",
                vmin=-1, vmax=1, center=0,
                cbar_kws={"shrink": 0.8})
    ax.set_title(f"{label} - Feature Correlation Matrix", fontsize=11)
    ax.tick_params(axis="x", rotation=30)

save_fig("10_feature_analysis")


# ==================================================================
# STEP 11 - MASTER VISUALIZATION DASHBOARD
# ==================================================================
section("STEP 11 - MASTER VISUALIZATION DASHBOARD")

fig = plt.figure(figsize=(20, 22))
fig.patch.set_facecolor("#0d1117")
gs  = fig.add_gridspec(4, 3, hspace=0.45, wspace=0.35)

ax_price = fig.add_subplot(gs[0, :])
ax1b = ax_price.twinx()
ax_price.plot(btc["date"],   btc["close"],   color=BTC_COLOR,   linewidth=1.2, label="BTC Close")
ax1b.plot(stock["date"], stock["close"], color=STOCK_COLOR, linewidth=1.2, label="Stock Close", alpha=0.8)
ax_price.set_ylabel("BTC Price (USD)",  color=BTC_COLOR)
ax1b.set_ylabel("Stock Price (USD)",    color=STOCK_COLOR)
ax_price.set_title("Price History - BTC (left axis) vs Stock (right axis)",
                   fontsize=11, fontweight="bold")
lines1, labs1 = ax_price.get_legend_handles_labels()
lines2, labs2 = ax1b.get_legend_handles_labels()
ax_price.legend(lines1+lines2, labs1+labs2, loc="upper left")
ax_price.grid(True)

ax_cum = fig.add_subplot(gs[1, 0])
ax_cum.plot(btc["date"],   btc["cum_return"]*100,   color=BTC_COLOR,   linewidth=1.2, label="BTC")
ax_cum.plot(stock["date"], stock["cum_return"]*100, color=STOCK_COLOR, linewidth=1.2, label="Stock")
ax_cum.set_title("Cumulative Returns (%)")
ax_cum.set_ylabel("% Return"); ax_cum.legend(); ax_cum.grid(True)

ax_vol = fig.add_subplot(gs[1, 1])
ax_vol.plot(btc["date"],   btc["volatility"]*100,   color=BTC_COLOR,   linewidth=1, label="BTC")
ax_vol.plot(stock["date"], stock["volatility"]*100, color=STOCK_COLOR, linewidth=1, label="Stock")
ax_vol.set_title(f"Rolling {WINDOW}d Volatility (Ann. %)")
ax_vol.legend(); ax_vol.grid(True)

ax_dist = fig.add_subplot(gs[1, 2])
ax_dist.hist(btc["daily_return"].dropna()*100,   bins=60, color=BTC_COLOR,
             alpha=0.65, density=True, label="BTC")
ax_dist.hist(stock["daily_return"].dropna()*100, bins=60, color=STOCK_COLOR,
             alpha=0.65, density=True, label="Stock")
ax_dist.set_title("Daily Return Distribution")
ax_dist.set_xlabel("Daily Return (%)"); ax_dist.legend(); ax_dist.grid(True)

ax_anom = fig.add_subplot(gs[2, :2])
ax_anom.plot(btc["date"], btc["close"], color=BTC_COLOR, linewidth=1, alpha=0.8)
anom_b = btc[btc["anomaly"]]
ax_anom.scatter(anom_b["date"], anom_b["close"],
                color=DANGER, s=30, zorder=5, label=f"BTC Anomalies ({len(anom_b)})")
ax_anom.set_title("Bitcoin Price with Anomalies")
ax_anom.legend(); ax_anom.grid(True)

ax_corr = fig.add_subplot(gs[2, 2])
ax_corr.plot(merged["date"], merged["rolling_corr"], color="#a371f7", linewidth=1)
ax_corr.axhline(0, color="#8b949e", linewidth=0.8, linestyle="--")
ax_corr.fill_between(merged["date"], merged["rolling_corr"], 0,
                     where=merged["rolling_corr"] > 0, alpha=0.2, color=SUCCESS)
ax_corr.fill_between(merged["date"], merged["rolling_corr"], 0,
                     where=merged["rolling_corr"] < 0, alpha=0.2, color=DANGER)
ax_corr.set_title("Rolling Correlation (60d)")
ax_corr.set_ylabel("Pearson r"); ax_corr.grid(True)

ax_fc = fig.add_subplot(gs[3, :2])
ax_fc.plot(range(len(btc_ts)), btc_ts*100,
           color=BTC_COLOR, alpha=0.6, linewidth=1, label="Actual BTC Returns")
ax_fc.plot(idx_test, forecast.values*100,
           color=DANGER, linewidth=2, label="ARIMA Forecast")
ax_fc.axvline(len(train), color="#8b949e", linestyle="--", linewidth=1)
ax_fc.set_title("ARIMA Forecast on BTC Daily Returns")
ax_fc.set_xlabel("Time Step"); ax_fc.set_ylabel("Daily Return (%)")
ax_fc.legend(); ax_fc.grid(True)

ax_sharpe2 = fig.add_subplot(gs[3, 2])
bars2 = ax_sharpe2.bar(["BTC", "Stock"], [btc_sharpe, stock_sharpe],
                       color=[BTC_COLOR, STOCK_COLOR], width=0.5)
ax_sharpe2.axhline(0, color="#8b949e", linewidth=0.8)
for bar, val in zip(bars2, [btc_sharpe, stock_sharpe]):
    ax_sharpe2.text(bar.get_x() + bar.get_width()/2,
                    val + 0.01 if val >= 0 else val - 0.07,
                    f"{val:.3f}", ha="center", fontweight="bold",
                    color="#e6edf3", fontsize=10)
ax_sharpe2.set_title("Sharpe Ratio Comparison")
ax_sharpe2.set_ylabel("Annualised Sharpe"); ax_sharpe2.grid(True, axis="y")

fig.suptitle("BITCOIN vs STOCK - MASTER DASHBOARD",
             fontsize=17, fontweight="bold", color="#e6edf3", y=0.995)
save_fig("11_master_dashboard")


# ==================================================================
# STEP 12 - INSIGHT GENERATION
# ==================================================================
section("STEP 12 - INSIGHT GENERATION")

btc_vol_mean   = btc["volatility"].mean() * 100
stock_vol_mean = stock["volatility"].mean() * 100
btc_tot_ret    = btc["cum_return"].iloc[-1] * 100
stock_tot_ret  = stock["cum_return"].iloc[-1] * 100
btc_anomaly_n  = btc["anomaly"].sum()
stk_anomaly_n  = stock["anomaly"].sum()

insights = f"""
{SECTION_BAR}
  FINAL INSIGHTS SUMMARY
{SECTION_BAR}

  Analysis Period : {common_start.date()}  to  {common_end.date()}

{"-" * 65}
RETURNS
  BTC   total cumulative return : {btc_tot_ret:+.1f}%
  Stock total cumulative return : {stock_tot_ret:+.1f}%
  {'Bitcoin' if btc_tot_ret > stock_tot_ret else 'Stock'} delivered higher absolute returns over the period.

RISK / VOLATILITY
  BTC   avg annualised volatility : {btc_vol_mean:.1f}%
  Stock avg annualised volatility : {stock_vol_mean:.1f}%
  BTC is approx. {btc_vol_mean/stock_vol_mean:.1f}x more volatile than the stock,
  confirming crypto's high-risk profile.

RISK-ADJUSTED RETURN (Sharpe Ratio)
  BTC   Sharpe : {btc_sharpe:.3f}
  Stock Sharpe : {stock_sharpe:.3f}
  {'Bitcoin' if btc_sharpe > stock_sharpe else 'Stock'} offers better risk-adjusted returns.
  A Sharpe > 1.0 is generally considered good.

CORRELATION
  Daily return correlation : {return_corr:.4f}
  {"Low correlation - Bitcoin and the stock move largely independently."
    if abs(return_corr) < 0.3 else
    "Moderate correlation - some co-movement observed."}
  This {"supports" if abs(return_corr) < 0.3 else "weakens"} the case for
  portfolio diversification by holding both assets.

ANOMALIES DETECTED
  BTC   extreme days : {btc_anomaly_n}
  Stock extreme days : {stk_anomaly_n}
  BTC experiences {'more' if btc_anomaly_n > stk_anomaly_n else 'fewer'}
  crash/spike events, consistent with its higher volatility.

PREDICTIVE MODELING
  Linear Regression R2 (BTC)   : {btc_r2:.4f}
  Linear Regression R2 (Stock) : {stock_r2:.4f}
  Open/High/Low/Volume features {'strongly' if max(btc_r2,stock_r2)>0.9 else 'moderately'}
  explain intraday close prices (expected: intraday OHLC are highly collinear).

{"-" * 65}
CONCLUSION
  Bitcoin  : HIGH risk, HIGH return, HIGH volatility, MORE anomalies
  Stock    : LOWER risk, steadier growth, fewer extreme events

  For aggressive investors, Bitcoin offers outsized gains but requires
  strong risk tolerance.
  For conservative investors, the stock delivers more predictable
  risk-adjusted performance.
  Holding both diversifies a portfolio when correlation is low.
{"-" * 65}
"""

print(insights)

with open("12_insights.txt", "w") as f:
    f.write(insights)
print("  Saved: 12_insights.txt")


# ==================================================================
# DONE
# ==================================================================
print(f"\n{SECTION_BAR}")
print("  ALL STEPS COMPLETE - outputs saved in current directory")
print(f"{SECTION_BAR}\n")
print("  Generated files:")
outputs = [
    "03_return_analysis.png",
    "04_risk_analysis.png",
    "05_multi_asset_comparison.png",
    "06_correlation_analysis.png",
    "07_anomaly_detection.png",
    "08_arima_model.png",
    "08b_acf_pacf.png",
    "09_regression_model.png",
    "10_feature_analysis.png",
    "11_master_dashboard.png",
    "12_insights.txt",
]
for o in outputs:
    print(f"    {o}")
