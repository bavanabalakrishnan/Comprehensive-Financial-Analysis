# Bitcoin vs Stock — Comprehensive Financial Analysis

A Python script that compares Bitcoin and a traditional stock across returns, risk,
correlation, anomalies, time-series forecasting, and regression modeling — producing
a full set of charts and a written insights summary.

## What it does

1. **Data Collection** — loads BTC and stock price CSVs (or generates synthetic
   demo data if the files aren't found).
2. **Preprocessing** — cleans columns, parses dates, handles missing values,
   aligns both assets to a common date range.
3. **Return Analysis** — daily and cumulative returns.
4. **Risk Analysis** — rolling annualized volatility and Sharpe ratio.
5. **Multi-Asset Comparison** — normalized price, return distributions, risk/return scatter.
6. **Correlation Analysis** — price/return correlation and 60-day rolling correlation.
7. **Anomaly Detection** — Z-score based extreme-move flagging.
8. **Time Series Modeling** — ARIMA(2,0,2) forecast on BTC daily returns, with ACF/PACF plots.
9. **Regression Model** — Linear regression predicting close price from OHLV features.
10. **Feature Analysis** — correlation heatmaps per asset.
11. **Master Dashboard** — a single combined figure of all key results.
12. **Insight Generation** — a plain-text summary (`12_insights.txt`) of findings.

## Datasets

Download the following from Kaggle and place them in the project folder:

| Asset   | Source | Expected filename |
|---------|--------|--------------------|
| Bitcoin | [priyamchoksi/bitcoin-historical-prices-and-activity-2010-2024](https://www.kaggle.com/datasets/priyamchoksi/bitcoin-historical-prices-and-activity-2010-2024) | `btc_price.csv` |
| Stock   | [anitarostami/historical-stock-price-dataset](https://www.kaggle.com/datasets/anitarostami/historical-stock-price-dataset) | `stock_price.csv` |

> If the CSVs are missing, the script automatically generates synthetic demo data
> so it can still run end-to-end.

## Setup & Usage

```bash
pip install pandas numpy matplotlib seaborn scipy statsmodels scikit-learn
python financial_analysis_project.py
```

## Output

Running the script generates the following in the project directory:

- `03_return_analysis.png`
- `04_risk_analysis.png`
- `05_multi_asset_comparison.png`
- `06_correlation_analysis.png`
- `07_anomaly_detection.png`
- `08_arima_model.png`
- `08b_acf_pacf.png`
- `09_regression_model.png`
- `10_feature_analysis.png`
- `11_master_dashboard.png`
- `12_insights.txt`

These generated files (along with the raw CSVs) are excluded from version control
via `.gitignore` — only the source code is tracked.

## Tech Stack

- pandas / numpy — data wrangling
- matplotlib / seaborn — visualization
- scipy — statistics (Z-score anomaly detection)
- statsmodels — ARIMA time-series modeling
- scikit-learn — linear regression, scaling, metrics

## License

Add a license of your choice (e.g. MIT) if you plan to share this repository publicly.
